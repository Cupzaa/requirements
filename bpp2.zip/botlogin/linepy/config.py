from in akad
